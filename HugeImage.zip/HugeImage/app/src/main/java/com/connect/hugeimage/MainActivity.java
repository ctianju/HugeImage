package com.connect.hugeimage;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.connect.hugeimage.databinding.ActivityMainBinding;
import com.connect.mylibrary.subscaleview.ImageSource;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Glide.with(this).asBitmap()
                .load(Uri.parse("https://i-blog.csdnimg.cn/blog_migrate/fd0fbb413250cacf00b78d6766adef87.jpeg"))
                .into(new CustomTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(@NonNull Bitmap resource,  Transition<? super Bitmap> transition) {
                                // 在这里可以获取到加载的Bitmap对象，进行进一步的处理
                                binding.imageView.setImage(ImageSource.bitmap(resource));
                            }

                            @Override
                            public void onLoadCleared( Drawable placeholder) {
                                // 可选的清除操作
                            }
                        });

    }
}